package com.example.evaltamgochi;

public class Task {
    private String Title;
    private String Description;

    private boolean State;

    public Task(String title, String description, boolean state) {
        Title = title;
        Description = description;
        State = state;
    }

    public String toString() {
        return
                "Title='" + Title + '\'' +
                ", Description='" + Description + '\'' +
                ", State=" + State;
    }

    public String getTitle() {
        return Title;
    }

    public String getDescription() {
        return Description;
    }

    public boolean isState() {
        return State;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public void setState(boolean state) {
        State = state;
    }
}
