package com.example.evaltamgochi;

import javafx.application.Application;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.TextFieldListCell;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.lang.reflect.Type;
import java.security.PrivateKey;
import java.util.*;

public class HelloApplication extends Application {
    public Integer money = 50;

    private Integer RedPrice = 5;
    private Integer BluePrice = 10;
    private Integer GreenPrice = 20;
    private Integer reward = 10;

    @Override
    public void start(Stage stage) throws IOException {
        // creation money
        Label cash = new Label("vous avez "+ money.toString() + " gold");

        // pour debuter
        Task t = new Task("Votre premiere tache","cliquer sur valider", true);
        Item Red = new Item("Restore  la vie","Buff","Rouge",5);
        Item Blue = new Item("Restore le mana", "Buff","Bleu",10);
        Item Green = new Item("Restore mana et vie","Plante","Verte",20);

        // creation de liste observable pour les liste view
        ObservableList<String> listTask2 = FXCollections.observableArrayList(t.toString());
        ObservableList<String> listShop2 = FXCollections.observableArrayList(Red.toString(),Blue.toString(),Green.toString());
        ObservableList<String> iventaire2 = FXCollections.observableArrayList(Red.toStringInv(), Blue.toStringInv(),Green.toStringInv());


        // creation du layout layout
        BorderPane mainLayout = new BorderPane();


        // creation des textfield pour le form
        TextField titleTask = new TextField();
        titleTask.setPromptText("Entrer le titre de la tache");
        TextField descriptionTask = new TextField();
        descriptionTask.setPromptText("Entrer votre description de la tache");


        // creation des boutons pour acheter et creer
        Button buy = new Button("Acheter");
        Button create = new Button("Crée");
        Button valid = new Button("Valider");



        // creation du conteneur des boutons
        HBox bottom = new HBox(buy,valid,create);
        bottom.setAlignment(Pos.CENTER);



        //creation des listview pour les task et les item et inventaire
        ListView listTask = new ListView<String>(listTask2);
        listTask.setEditable(true);
        listTask.setCellFactory(TextFieldListCell.forListView());
        ListView listShop = new ListView<String>(listShop2);
        listShop.setEditable(true);
        ListView iventaire = new ListView<String>(iventaire2);
        iventaire.setEditable(true);

        // creation du form
        VBox formtask = new VBox(titleTask,descriptionTask,iventaire,cash);

        // set up pour le layout border
        mainLayout.setRight(listTask);
        mainLayout.setCenter(formtask);
        mainLayout.setLeft(listShop);
        mainLayout.setBottom(bottom);

        // creation de l event pour les boutons
        create.setOnAction(actionEvent -> {
            listTask2.add(new Task(titleTask.getCharacters().toString(),descriptionTask.getCharacters().toString(),true).toString());

        });

        valid.setOnAction(actionEvent -> {
            String todel = (String) listTask.getSelectionModel().getSelectedItem();
            if (listTask2.isEmpty()) {
                return;
            }
            listTask2.remove(todel);
            money += reward;
            cash.setText("Vous avez "+ money.toString()+ " gold");

            listTask.refresh();
        });

        buy.setOnAction(actionEvent -> {
            String tobuy = (String) listShop.getSelectionModel().getSelectedItem();
            if (tobuy.contains("Rouge")) {
                if (RedPrice > money) {
                    return;
                }else {
                    iventaire2.add(Red.toStringInv());
                    money -= RedPrice;
                    cash.setText("Vous avez "+ money.toString()+ " gold");
                }
            } else if (tobuy.contains("Bleu")) {
                if (BluePrice > money) {
                    return;
                }else {
                    iventaire2.add(Blue.toStringInv());
                    money -= BluePrice;
                    cash.setText("Vous avez "+ money.toString()+ " gold");
                }
            } else if (tobuy.contains("Verte")) {
                if (GreenPrice > money) {
                    return;
                }else {
                    iventaire2.add(Green.toStringInv());
                    money -= GreenPrice;
                    cash.setText("Vous avez "+ money.toString()+" gold");
                }

            }

            iventaire.refresh();
        });


        Scene mainScene = new Scene(mainLayout,1200,600);
        stage.setTitle("Tamagochi of Legend");
        stage.setScene(mainScene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}