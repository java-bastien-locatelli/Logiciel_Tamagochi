package com.example.evaltamgochi;

public class Item {
    private String Effect;
    private String Type;
    private String Color;
    private Integer Price;

    public Item(String effect, String type, String color,Integer price) {
        Effect = effect;
        Type = type;
        Color = color;
        Price = price;
    }

    @Override
    public String toString() {
        return
                "Effect='" + Effect + '\'' +
                ", Type='" + Type + '\'' +
                ", Color='" + Color + '\'' +
                ", Price=" + Price;
    }

    public String toStringInv() {
        return
                "Effect='" + Effect + '\'' +
                ", Type='" + Type + '\'' +
                ", Color='" + Color + '\'' ;
    }

    public String getEffect() {
        return Effect;
    }

    public void setEffect(String effect) {
        Effect = effect;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String color) {
        Color = color;
    }

    public Integer getPrice() {
        return Price;
    }

    public void setPrice(Integer price) {
        Price = price;
    }
}
