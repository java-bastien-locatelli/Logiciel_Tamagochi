module com.example.evaltamgochi {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.evaltamgochi to javafx.fxml;
    exports com.example.evaltamgochi;
}